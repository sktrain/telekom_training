package dataClumps;

public enum Geschlecht { W, M, D

}
