package dataClumps;

public class Application {
	
	public static void main(String args[]) {
		
		Person p = new Person(args[0],
				              args[1],
				              Integer.valueOf(args[2]),
				              args[3],
				              args[4]);
		
	    p.welcomeNew();
	    p.work();
	}

}
