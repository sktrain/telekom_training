package messageChain;

public class Application
{
   public static void main(String[] args)
   {
	   //Simulation Objectaufbau
	   Configuration conf = new Configuration();
	   EmployeeConfig econf = new EmployeeConfig(conf);
	   Employee e = new Employee(econf);
	   print(e);
	}
   
   static void print(Employee e){
	   String s = e.getConfiguration();  //Client braucht nur einen Aufruf
	   System.out.println(s);
   }
}
	   
	   
class Employee{
	
	private EmployeeConfig econf;
	
	public Employee(EmployeeConfig econf) {
		super();
		this.econf = econf;
	}

	//kapselt weg
	public String getConfiguration() {
		return econf.getConfiguration().getConfiguration();
	}
}

class EmployeeConfig{
	
	private Configuration conf;
	
	public EmployeeConfig(Configuration conf) {
		super();
		this.conf = conf;
	}

	public Configuration getConfiguration() {
		return conf;
	}	
}

class Configuration{
	
	public String getConfiguration() {
		return "Config";
	}
}
