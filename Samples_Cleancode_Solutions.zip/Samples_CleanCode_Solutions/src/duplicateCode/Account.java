package duplicateCode;

public class Account {
    
    private String type;
    private String accountNumber;
    private int amount;
   
    public Account(String type,String accountNumber,int amount)
    {
           this.amount=amount;
           this.type=type;
           this.accountNumber=accountNumber;
    }
   
   
    private void validate(Account account) throws Exception {
		if(account.amount <= 500)
           {
                  throw new Exception("Mininum balance should be over 500");
           }
	}
    
    public void debit(int debit) throws Exception
    {
           validate(this);
          
           amount = amount-debit;
           System.out.println("Now amount is" + amount);
          
    }
   
    public void transfer(Account from,Account to,int cerditAmount) throws Exception
    {
           validate(from);          
           to.amount = amount+cerditAmount;
          
    }

    //ist diese Methode wirklich notwendig??
    public void sendWarningMessage()
    {
           if(amount <= 500)
           {
                  System.out.println("amount should be over 500");
           }
    }   
	
   
	
 

}