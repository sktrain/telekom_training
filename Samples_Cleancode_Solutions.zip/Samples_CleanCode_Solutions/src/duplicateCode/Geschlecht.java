package duplicateCode;

public enum Geschlecht { W, M, D

}
