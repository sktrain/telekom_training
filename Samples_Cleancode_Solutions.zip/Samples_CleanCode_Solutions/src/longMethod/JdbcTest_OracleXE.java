/* JDBC_Zugriff auf Oracle Express
 * Voraussetzung: JAR-Datei mit JDBC-Driver ist im Classpath,
 * das DBMS l�uft und die Zugangsinfos stimmen
 */

// Refactoring
//Schritt 1:  try mit Ressourcen (Java-specific) spart finally-Block
//Schritt 2:  extract Method
//Weitere Verbesserung: siehe package "similarCode"

package longMethod;

import java.io.PrintWriter;
import java.sql.*;

public class JdbcTest_OracleXE {

	public static void main(String[] args) {

		DriverManager.setLogWriter(new PrintWriter(System.out));

		loadDriver();

		try (Connection myconnect = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XEPDB1", "hr",
					"hr"))  {
			System.out.println(myconnect.getMetaData().getDatabaseProductName());
			
			executeQuery1(myconnect);

			executeUpdate(myconnect);

			executeQuery2(myconnect);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	private static void executeQuery2(Connection con) throws SQLException {
		Statement st = con.createStatement();
		ResultSet rs;
		ResultSetMetaData rsmd;
		rs = st.executeQuery("SELECT EMPLOYEE_ID, LAST_NAME FROM employees WHERE EMPLOYEE_ID = 100");
		rsmd = rs.getMetaData();
		System.out.println("Insgesamt Spalten verf�gbar: " + rsmd.getColumnCount());
		rs.next();
		System.out.println(rs.getString("EMPLOYEE_ID") + "\t:\t" + rs.getString("LAST_NAME"));
	}

	private static void executeUpdate(Connection con) throws SQLException {
		PreparedStatement ps = con
				.prepareStatement("UPDATE employees SET LAST_NAME = ? WHERE EMPLOYEE_ID = ?");
		ps.setString(1, "K�nig");
		ps.setLong(2, 100);
		ps.executeUpdate();
	}

	private static void executeQuery1(Connection con) throws SQLException {
		Statement st = con.createStatement();
		String query = "SELECT * from employees where rownum < 10";
		ResultSet rs = st.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		System.out.println("Insgesamt Spalten verf�gbar: " + rsmd.getColumnCount());
		while (rs.next()) { 
			System.out.println(rs.getString("last_name") + " | " + rs.getString("first_name") + " | "
					+ rs.getBigDecimal("salary"));
		}
	}

	private static void loadDriver() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
