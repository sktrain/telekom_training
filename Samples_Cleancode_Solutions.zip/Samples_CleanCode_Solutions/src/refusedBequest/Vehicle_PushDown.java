package refusedBequest;

public class Vehicle_PushDown  
{   //sonstiger Code ...
	
    // protected String drive() { return "I am Driving"; }  
    //protected String fly() { return "I am Flying"; }    
}       


class Plane extends  Vehicle_PushDown
{
	public  String fly() {
		return "I am Flying" +" with plane";
	} 	
}  

class Car extends  Vehicle_PushDown
{
	public  String drive() {
		return "I am Driving" +" with car";
	} 	
}  
