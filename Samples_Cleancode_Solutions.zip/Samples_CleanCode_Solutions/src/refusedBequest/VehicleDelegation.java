package refusedBequest;

public class VehicleDelegation {
	
	//other code

	protected String drive() {
		return "I am Driving";
	}

	protected String fly() {
		return "I am Flying";
	}
}

class PlaneDelegation {
	private VehicleDelegation veh;

	public PlaneDelegation(VehicleDelegation veh) {
		super();
		this.veh = veh;
	}

	public String fly() {
		return veh.fly() + " with plane";
	}
}

class CarDelegation {

	private VehicleDelegation veh;

	public CarDelegation(VehicleDelegation veh) {
		super();
		this.veh = veh;
	}

	public String drive() {
		return veh.drive() + " with car";
	}

}
