package switchStatements;

public class BirdApplication {
	
	public static void main(String[] args) {
		
		Bird b = Bird.getBirdInstance("Goldfinch");
		
		System.out.println(b.GetColors());
		
		System.out.println(b.GetSizeRange());
		
		b = Bird.getBirdInstance("Chickadee");
		
		System.out.println(b.GetColors());
		
		System.out.println(b.GetSizeRange());
		
	}
	
	

}
