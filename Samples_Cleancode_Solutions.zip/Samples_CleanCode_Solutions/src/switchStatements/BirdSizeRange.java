package switchStatements;

public class BirdSizeRange {
	
	private int lower;
	private int upper;
	
	public BirdSizeRange(int lower, int upper) {
		super();
		this.lower = lower;
		this.upper = upper;
	}

	@Override
	public String toString() {
		return "BirdSizeRange [lower=" + lower + ", upper=" + upper + "]";
	}	

}
