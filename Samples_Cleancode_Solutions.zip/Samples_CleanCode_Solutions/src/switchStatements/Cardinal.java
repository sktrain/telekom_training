package switchStatements;

import java.util.Arrays;
import java.util.List;

public class Cardinal implements Bird {

	@Override
	public List<String> GetColors()
	{
		return Arrays.asList("Black", "Red");			
	}
	
	@Override
	public BirdSizeRange GetSizeRange()
	{
		return new BirdSizeRange(8, 9);
	}
	

}
