package switchStatements;

import java.util.Arrays;
import java.util.List;

public class Chickadee implements Bird {

	@Override
	public List<String> GetColors()
	{
		return Arrays.asList("Black", "Tan", "White");
	}

	@Override
	public BirdSizeRange GetSizeRange() {
		return new BirdSizeRange(4, 5);
	}

}
