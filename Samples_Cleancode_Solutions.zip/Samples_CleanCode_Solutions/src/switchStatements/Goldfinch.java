package switchStatements;

import java.util.Arrays;
import java.util.List;

public class Goldfinch implements Bird {

	@Override
	public List<String> GetColors()
	{
		return Arrays.asList("Black", "Yellow", "White");
	}

	@Override
	public BirdSizeRange GetSizeRange()
	{
		return new BirdSizeRange(4, 6);
	}

}
