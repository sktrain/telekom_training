package switchStatements;

import java.util.List;

public interface Bird {
	
	public abstract List<String> GetColors();
	
	public abstract BirdSizeRange GetSizeRange();
	
	//Factory kann ab Java 8 direkt hier implementiert werden
	
	public static Bird getBirdInstance(final String birdtype) {
		
		switch (birdtype)
		{
			case "Cardinal":
				return new Cardinal();
			case "Goldfinch":
				return new Goldfinch();
			case "Chickadee":
				return new Chickadee();
			default: throw new RuntimeException("invalid birdtype");
		}		
	}

}
