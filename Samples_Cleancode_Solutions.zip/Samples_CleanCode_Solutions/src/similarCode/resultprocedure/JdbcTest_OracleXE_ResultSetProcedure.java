/* JDBC_Zugriff auf Oracle Express
 * Voraussetzung: JAR-Datei mit JDBC-Driver ist im Classpath,
 * das DBMS l�uft und die Zugangsinfos stimmen
 */

// Refactoring
// Schritt 1: Zusammenfassen der Infrastruktur-Bereitstellung:
// (getConnection() k�mmert sich um Treiber und liefert DB-Verbindung)
// Schritt 2: Templating der SQL-Zugriffe (generelle Verwendung von parametrisierten Queries
// und Vereinheitlichung der Query-Verarbeitung) --> Spring wird das noch besser machen!!
// Schritt 3: Individuelle Verarbeitung des Resultsets auslagern (Consumer nutzen)

package similarCode.resultprocedure;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.*;
import java.util.function.Consumer;

public class JdbcTest_OracleXE_ResultSetProcedure {

	public static void main(String[] args) {

		try (Connection myconnect = getConnection()) {
			System.out.println(myconnect.getMetaData().getDatabaseProductName());

			Consumer<ResultSet> cs = rs -> {
				try {
					ResultSetMetaData rsmd = rs.getMetaData();
					int columnCount = rsmd.getColumnCount();
					System.out.println("Insgesamt Spalten verf�gbar: " + columnCount);

					while (rs.next()) {
						StringBuilder sb = new StringBuilder();
						for (int j = 1; j <= columnCount; ++j) {
							sb = sb.append(rs.getString(j)).append(" | ");
						}
						System.out.println(sb);

					}
				} catch (SQLException e) {
					throw new RuntimeException(e);
				}
			};

			executeQuery(cs, myconnect, "SELECT * from employees where rownum < ?", 10);

			executeUpdate(myconnect, "UPDATE employees SET LAST_NAME = ? WHERE EMPLOYEE_ID = ?", "King", 100);

			executeQuery(cs, myconnect, "SELECT employee_id, last_name FROM employees WHERE EMPLOYEE_ID = ?", 100);
		
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
	}

	private static Connection getConnection() throws SQLException, ClassNotFoundException {
		DriverManager.setLogWriter(new PrintWriter(System.out));
		Class.forName("oracle.jdbc.OracleDriver");
		return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XEPDB1", "hr", "hr");
	}

	private static void executeUpdate(Connection con, String sqldml, Object... params) throws SQLException {
		PreparedStatement ps = con.prepareStatement(sqldml);
		for (int i = 0; i < params.length; ++i) {
			ps.setObject(i + 1, params[i]);
		}
		ps.executeUpdate();
	}

	private static void executeQuery(Consumer<ResultSet> cons, Connection con, String query, Object... params)
			throws SQLException {
		PreparedStatement ps = con.prepareStatement(query);
		for (int i = 0; i < params.length; ++i) {
			ps.setObject(i + 1, params[i]);
		}
		ResultSet rs = ps.executeQuery();
		cons.accept(rs);
	}
}
