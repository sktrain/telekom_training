package sk.train;

public class FakultaetTest {

	public static void main(String[] args) throws InterruptedException {

          for (int i = 1; i < 25; i++) {
			System.out.println("fakultaet von " + i + " ist: " + Fakultaet.fakrek(i));
		}
          
//        Fakultaet f = new Fakultaet();
//        System.out.println(f.fakultaet(5));
        
//		Thread t = new Thread(() -> {
//			for (int i = 0; i < 100; ++i) {
//				System.out.println("hier neuer Thread");
//				try {
//					Thread.sleep(1000);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		});
//
//		t.start();
//        
//        Thread.sleep(10000);
//        
//        System.out.println("Hier main-Thread");
		
//		System.out.println(0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1);
	}

}
