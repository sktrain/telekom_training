package sk.train;

import java.math.BigInteger;

public class Fakultaet {
	
	
	private Fakultaet() {
		super();
	}
	
	//Methode f�r die Fakultaetsberechnung
	//Fakultaet von n (positive Ganzzahl): 1 * 2 * ... * n
	//static ja oder nein
	
	public static int fakultaet(int input) {
			int result = 1;
			for (int i = 1; i <=input; ++i) {
				result = result * i;
			}
			return result;
	}
	
	public static int fakultaet_overflow(int input) {
		int result = 1;
		for (int i = 1; i <=input; ++i) {
			result = Math.multiplyExact(result, i);
		}
		return result;		
	}
	
	public static BigInteger fakultaetBig(int input) {
		BigInteger result = BigInteger.ONE; //new BigInteger(""+1)
		for (int i = 1; i <=input; ++i) {
			result = result.multiply(new BigInteger("" + i));
		}
		return result;		
	}
	
	public static int fakrek(int input) {
		if (input == 1) { return 1;}
		else return input * fakrek(--input);
	}
	
	
	
	
	//Aufrufer schreiben: Fakultaet f�r 1 - 25 berechnen und ausgeben

}
