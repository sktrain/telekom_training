/* Mitarbeiter-L�sung erweitert um verschiedene Sortiervarianten:
 * Lambdas werden kurz eingef�hrt.
 */

package sk.train.ma.strategy;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;

public class MItarbeiterVerwaltungTest {

	public static void main(String[] args) {

		MitarbeiterVerwaltung mv = new MitarbeiterVerwaltung();
		
		//Store und Load
				
		System.out.println(mv.getMap().size());
		
		Mitarbeiter neu = new Mitarbeiter(200, "Max", "Meier", 
				                          LocalDate.of(1990, 1, 1), 
				                          LocalDate.of(2010, 1, 1),
				                          Geschlecht.M,
				                          new FixGehaltModell(new BigDecimal(5000)));
		String persnr = mv.addMitarbeiter(neu);   
		
		Mitarbeiter hinzugefuegt = mv.getMitarbeiter(persnr); 
		
		System.out.println(hinzugefuegt == neu);
		System.out.println(mv.getMap().size());
		
		mv.store();
		
		mv.delMitarbeiter(neu);
		
		System.out.println(mv.getMap().size());
		
		mv = null;  //Referenz frei geben
		
		mv = new MitarbeiterVerwaltung();  //dadurch load, da zuvor store
		
		System.out.println(mv.getMap().size());
		System.out.println(mv.getMitarbeiter(persnr));	
		
		
		//Textfile
		mv.writeToFile("Mitarbeiterliste.txt");
		
		
	}
}
