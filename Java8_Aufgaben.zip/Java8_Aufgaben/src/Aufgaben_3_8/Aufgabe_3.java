package Aufgaben_3_8;

public class Aufgabe_3 {

	public static void main(String[] args) {

		//use class Person

	}

}
