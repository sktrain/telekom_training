package Aufgaben_6_13;

public enum Gender
{
    MALE, FEMALE, UNKNOWN;
}