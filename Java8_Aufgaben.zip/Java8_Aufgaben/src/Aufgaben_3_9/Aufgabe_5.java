package Aufgaben_3_9;

import java.util.stream.IntStream;

public class Aufgabe_5 {
	
	public static void main(String[] args) {
		
		final IntStream ints = IntStream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		
		//....TODO....
	}

}
