package org.javacream.books.warehouse;


public class BooksServiceTest {

	
	/* Testen des BookService: MapBookService
	 * - Instantiierbar und Buch anlegbar 
	 * - funktioniert  findAllBooks()
	 * - ist nach hinzuf�gen eines Buches das Ergebnis von findAllBooks() korrekt
	 * - wird eine vern�nftige ISBN geliefert (not null)
	 * - funktioniert findBookByIsbn(): Erfolg + Fehlschlag (Exception wird erwartet)
	 * - funktioniert deleteBookByIsbn() 
	 * - funktioniert updateBook() (auch Preis-Grenze testen, darf nicht negativ sein)
	 * - funktioniert auch die Nutzung des Generators f�r die Spezialkategorien SchoolBook und SpecialistBook
	 * - was passiert bei newBook(), wenn Parameter null sind? 
	 * - funktionieren die booksList()-Varianten
	 * - funktioniert findBooksByPriceRange
	 */


}
