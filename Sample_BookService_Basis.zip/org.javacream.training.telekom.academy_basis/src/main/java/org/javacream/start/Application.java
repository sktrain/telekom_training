package org.javacream.start;

import java.util.Collection;
import java.util.HashMap;

import org.javacream.books.warehouse.Book;
import org.javacream.books.warehouse.BookException;
import org.javacream.books.warehouse.MapBooksService;

public class Application {

	private static final String WRONG_ISBN = "##ISBN##";
	private static final double PRICE = 9.99;

	public static void main(String[] args) {

		MapBooksService booksService = new MapBooksService();
		String ISBN;
		try {
			ISBN = booksService.newBook("TEST", PRICE, new HashMap<String, Object>());
		} catch (BookException e) {
			throw new RuntimeException(e.getMessage());
		}
		System.out.println("ISBN des neuen Buchs: " +ISBN);
		
		doTest(booksService);

	}
	
	private static void doTest(MapBooksService booksService) {

		try {
			Collection<Book> books = booksService.findAllBooks();
			System.out.println(books);
            final int startSize = books.size();
            String j2eeTitle = "Spring";
			String isbn = booksService.newBook(j2eeTitle, PRICE, new HashMap<String, Object>());
			books = booksService.findAllBooks();
			final int endSize = books.size();
			System.out.println("Size-Diff sollte 1 sein: " + (endSize - startSize));
			System.out.println("ISBN des neuen Buchs: " +isbn);
			System.out.println(booksService.findBookByIsbn(isbn));

			try {
				booksService.findBookByIsbn("ISBN-3");
				} catch (BookException e) {
				System.out.println("Exception kam: ok");
			}
			
			booksService.deleteBookByIsbn(isbn);
			System.out.println("Neue Size: " + booksService.findAllBooks().size());
			
		} catch (BookException bookException) {
			bookException.printStackTrace();
		}

	}

}
