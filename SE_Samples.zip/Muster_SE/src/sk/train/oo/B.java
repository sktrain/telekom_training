package sk.train.oo;

class B extends A {
	void foo() {
		System.out.println("B");
		
		
	}
	
	public static void main(String[] args) {
		new B().foo();
	}
}