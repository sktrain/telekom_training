package sk.train.oo;


/* per static Initializer, d.h. eager */

public class EagerSingleton {
	
	private static EagerSingleton single = new EagerSingleton();
	
	//static init
//	static
//	{
//		single = new EagerSingleton();
//	}
	
	private EagerSingleton() {
		super();
	}
	
	static EagerSingleton getInstance(){
		return single;
	}

}
