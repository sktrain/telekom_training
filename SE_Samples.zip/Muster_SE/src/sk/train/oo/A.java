package sk.train.oo;

public class A {
	A() {
		foo();
	}
	
	

	void foo() {
		System.out.println("A");
	}
}



	
