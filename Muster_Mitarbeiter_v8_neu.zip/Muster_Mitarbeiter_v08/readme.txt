sk.train.ma_verwaltung_abstract:

- Basisversion der Mitarbeiterklasse, sauberer Vererbung und 
abstrakter Elternklasse f�r die abstrakte getGehalt-Methode.
- Entsprechend kann die Mitarbeiterverwaltung die Gehaltssumme liefern.



sk.train.ma.strategy:

- Basisversion der Mitarbeiterklasse mit Gehaltsmodell (Has-A), 
  Gehaltsmodelle sind per Interface definiert (Strategy-Pattern umgesetzt).
- Entsprechend kann die Mitarbeiterverwaltung die Gehaltssumme liefern.
- Mitarbeiterklasse implementiert Comparable
- Weitere Comparatoren werden eingesetzt
- Factory f�r Gehaltsmodelle ist vorhanden
- Klassen haben Standardmethoden (toString, equals, hashcode) �berschrieben 



sk.train.ma.strategy.factorygeneral:

- nur zu Demo: Factory auf Basis Reflection