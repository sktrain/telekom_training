package sk.train.ma.strategy.factorygeneral;

import java.lang.reflect.InvocationTargetException;

public class ObjectFactoryImpl implements ObjectFactory {

//	// SINGLETON - Lazy-Variante, so nicht Thread-Safe
//	private static ObjectFactoryImpl instance ;
//	
//	private ObjectFactoryImpl( ) { }
//	
//	public static ObjectFactoryImpl getInstance( ) {
//		if ( instance == null )
//			instance = new ObjectFactoryImpl( );
//		return instance;
//	}
//	// SINGLETON Ende
	
	// SINGLETON - Eager-Variante  (sollte Thread-Safe sein)
	private static ObjectFactoryImpl instance = new ObjectFactoryImpl();
	
	private ObjectFactoryImpl( ) { }
	
	public static ObjectFactoryImpl getInstance( ) {
		return instance;
	}
	// SINGLETON Ende
	
	/**
	 * Objekterzeugung: setzt parameterlosen Konstruktor voraus
	 * @param pClassname Klassenname
	 */
	@Override
	public Object create( String pClassname ) {
		Object o = null;
		try {
			Class<?> klasse = Class.forName( pClassname );
				//o = klasse.newInstance( );	//deprecated ab Java 9
			o = klasse.getDeclaredConstructor().newInstance();
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException
				| InvocationTargetException | NoSuchMethodException | SecurityException e) {

			throw new RuntimeException("Factory cannot create", e);
		}  
		
		return o;
	} // Ende create 

	

} // Ende class
