package sk.train.ma.strategy.factorygeneral;

public interface ObjectFactory {

	public Object create( String pClassname );
	
} // Ende interface
