package sk.train.ma.strategy.factorygeneral;

public class ObjectFactoryTest {

	public static void main(String[] args) {
		 //nur mal zum Test: Nutzung der allgemeinen ObjectFactory
		 //setzt paramerlosen Konstruktor voraus
		 Object o = ObjectFactoryImpl.getInstance().create("sk.train.ma.strategy.MitarbeiterVerwaltung");
		 System.out.println(o.getClass());
	}

}
