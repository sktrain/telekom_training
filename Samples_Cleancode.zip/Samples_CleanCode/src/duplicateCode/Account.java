package duplicateCode;

public class Account {
    
    private String type;
    private String accountNumber;
    private int amount;
   
    public Account(String type,String accountNumber,int amount)
    {
           this.amount=amount;
           this.type=type;
           this.accountNumber=accountNumber;
    }
   
   
    public void debit(int debit) throws Exception
    {
           if(amount <= 500)
           {
                  throw new Exception("Mininum balance shuold be over 500");
           }
          
           amount = amount-debit;
           System.out.println("Now amount is" + amount);
          
    }
   
    public void transfer(Account from , Account to, int creditAmount) throws Exception
    {
           if(from.amount <= 500)
           {
                  throw new Exception("Mininum balance should be over 500");
           }
          
           to.amount = amount+creditAmount;
          
    }
   
    public void sendWarningMessage()
    {
           if(amount <= 500)
           {
                  System.out.println("amount should be over 500");
           }
    }   

}