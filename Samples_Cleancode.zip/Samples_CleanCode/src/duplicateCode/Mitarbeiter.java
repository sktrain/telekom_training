package duplicateCode;

public class Mitarbeiter {

	// Datenattribute
	private String persnr;
	private String vorname;
	private String nachname;
	private String abteilung;
	private int gehalt;

	// Konstruktoren
	
	public Mitarbeiter(String persnr, String vorname, String nachname, String abteilung, int gehalt) {
		super();
		this.persnr = persnr;
		this.vorname = vorname;
		this.nachname = nachname;
		this.abteilung = abteilung;
		this.gehalt = gehalt;
	}	

	public Mitarbeiter(String persnr, String vorname, String nachname, String abteilung) {
		super();
		this.persnr = persnr;
		this.vorname = vorname;
		this.nachname = nachname;
		this.abteilung = abteilung;
		this.gehalt = 0;
	}

	public Mitarbeiter(String persnr, String vorname, String nachname) {
		super();
		this.persnr = persnr;
		this.vorname = vorname;
		this.nachname = nachname;
		this.abteilung = "Unknown";
		this.gehalt = 0;
	}

	// Getter/Setter
	
	public String getPersnr() {
		return persnr;
	}

	public void setPersnr(String persnr) {
		this.persnr = persnr;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getAbteilung() {
		return abteilung;
	}

	public void setAbteilung(String abteilung) {
		this.abteilung = abteilung;
	}

	public int getGehalt() {
		return gehalt;
	}

	public void setGehalt(int gehalt) {
		this.gehalt = gehalt;
	}

	// �berschriebene Standardmethoden
	
	@Override
	public String toString() {
		return "Mitarbeiter [persnr=" + persnr + ", vorname=" + vorname + ", nachname=" + nachname + ", abteilung="
				+ abteilung + ", gehalt=" + gehalt + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((abteilung == null) ? 0 : abteilung.hashCode());
		result = prime * result + gehalt;
		result = prime * result + ((nachname == null) ? 0 : nachname.hashCode());
		result = prime * result + ((persnr == null) ? 0 : persnr.hashCode());
		result = prime * result + ((vorname == null) ? 0 : vorname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Mitarbeiter))
			return false;
		Mitarbeiter other = (Mitarbeiter) obj;
		if (abteilung == null) {
			if (other.abteilung != null)
				return false;
		} else if (!abteilung.equals(other.abteilung))
			return false;
		if (gehalt != other.gehalt)
			return false;
		if (nachname == null) {
			if (other.nachname != null)
				return false;
		} else if (!nachname.equals(other.nachname))
			return false;
		if (persnr == null) {
			if (other.persnr != null)
				return false;
		} else if (!persnr.equals(other.persnr))
			return false;
		if (vorname == null) {
			if (other.vorname != null)
				return false;
		} else if (!vorname.equals(other.vorname))
			return false;
		return true;
	}
	
}