package dataClumps;

public class Application {
	
	public static void main(String args[]) {
	    String firstName = args[0];
	    String lastName = args[1];
	    Integer age = Integer.valueOf(args[2]);
	    String occupation = args[3];
	    String city = args[4];
	    welcomeNew(firstName, lastName, age, occupation, city);
	    work(firstName, occupation, city);
	}

	public static void welcomeNew(String firstName, String lastName, Integer age, String occupation, String city) {
	    System.out.printf("Welcome %s %s, a %d-year-old from %s who works as a%s\n",firstName, lastName, age, city, occupation);
	}
	
	public static void work(String firstName, String occupation, String city) {
        System.out.printf("This is %s working hard on %s in %s", firstName, occupation, city);
    }

}
