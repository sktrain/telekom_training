package messageChain;

public class Application
{
   public static void main(String[] args)
   {
	   //Simulation Objectaufbau
	   Configuration conf = new Configuration();
	   EmployeeConfig econf = new EmployeeConfig(conf);
	   Employee e = new Employee(econf);
	   print(e);
	}
   
   static void print(Employee e){
	   String s = e.getConfiguration().getConfiguration().getConfiguration();
	   System.out.println(s);
   }
}
	   
	   
class Employee{
	
	private EmployeeConfig econf;
	
	public Employee(EmployeeConfig econf) {
		super();
		this.econf = econf;
	}

	public EmployeeConfig getConfiguration() {
		return econf;
	}
}

class EmployeeConfig{
	
	private Configuration conf;
	
	public EmployeeConfig(Configuration conf) {
		super();
		this.conf = conf;
	}

	public Configuration getConfiguration() {
		return conf;
	}	
}

class Configuration{
	
	public String getConfiguration() {
		return "Config";
	}
}
