package switchStatements;

public class BirdApplication {
	
	public static void main(String[] args) {
		
		Bird b = new Bird("Goldfinch");
		
		System.out.println(b.GetColors());
		
		System.out.println(b.GetSizeRange());
		
	}
	
	

}
