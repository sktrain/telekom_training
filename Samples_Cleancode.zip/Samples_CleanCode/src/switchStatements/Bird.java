package switchStatements;

import java.util.Arrays;
import java.util.List;

public class Bird
{
	private final String birdType;

	
	public Bird(String birdType) {
		super();
		this.birdType = birdType;
	}
	
	public List<String> GetColors()
	{
		switch (birdType)
		{
			case "Cardinal":
				return Arrays.asList("Black", "Red");
			case "Goldfinch":
				return Arrays.asList("Black", "Yellow", "White");
			case "Chickadee":
				return Arrays.asList("Black", "Tan", "White");
			default: throw new RuntimeException("invalid birdtype");
		}
	}
	
	public BirdSizeRange GetSizeRange()
	{
		switch (birdType)
		{
			case "Cardinal":
				return new BirdSizeRange(8, 9);
			case "Goldfinch":
				return new BirdSizeRange(4, 6);
			case "Chickadee":
				return new BirdSizeRange(4, 5);
			default: throw new RuntimeException("invalid birdtype");
		}
	}
}
