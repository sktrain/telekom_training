/* JDBC_Zugriff auf Oracle Express
 * Voraussetzung: JAR-Datei mit JDBC-Driver ist im Classpath,
 * das DBMS l�uft und die Zugangsinfos stimmen
 */

package longMethod;

import java.io.PrintWriter;
import java.sql.*;

public class JdbcTest_OracleXE {

	public static void main(String[] args) {

		DriverManager.setLogWriter(new PrintWriter(System.out));

		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
		}

		Connection myconnect = null;
		try  {
			 myconnect = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XEPDB1", "hr",
					"hr");
			System.out.println(myconnect.getMetaData().getDatabaseProductName());
			Statement st = myconnect.createStatement();
			String query = "SELECT * from employees where rownum < 10";
			ResultSet rs = st.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			System.out.println("Insgesamt Spalten verf�gbar: " + rsmd.getColumnCount());
			while (rs.next()) { 
				System.out.println(rs.getString("last_name") + " | " + rs.getString("first_name") + " | "
						+ rs.getBigDecimal("salary"));
			}

			PreparedStatement ps = myconnect
					.prepareStatement("UPDATE employees SET LAST_NAME = ? WHERE EMPLOYEE_ID = ?");
			ps.setString(1, "K�nig");
			ps.setLong(2, 100);
			ps.executeUpdate();

			rs = st.executeQuery("SELECT EMPLOYEE_ID, LAST_NAME FROM employees WHERE EMPLOYEE_ID = 100");
			rsmd = rs.getMetaData();
			System.out.println("Insgesamt Spalten verf�gbar: " + rsmd.getColumnCount());
			rs.next();
			System.out.println(rs.getString("EMPLOYEE_ID") + "\t:\t" + rs.getString("LAST_NAME"));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (myconnect != null) {
				try {
					myconnect.close();
				} catch (SQLException e) {
				}
			}			
		}
	}
}
