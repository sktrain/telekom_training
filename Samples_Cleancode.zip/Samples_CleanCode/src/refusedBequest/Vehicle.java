package refusedBequest;

public class Vehicle  
{  
    protected String drive() { return "I am Driving"; }  
    protected String fly() { return "I am Flying"; }    
}       


class Plane extends  Vehicle
{
	@Override
	public  String fly() {
		return super.fly() +" with plane";
	} 
	
	//what shall we do with drive()?
	
}  

class Car extends  Vehicle
{
	@Override
	public  String drive() {
		return super.drive() +" with car";
	} 
	
	//what shall we do with fly()?
	
}  
