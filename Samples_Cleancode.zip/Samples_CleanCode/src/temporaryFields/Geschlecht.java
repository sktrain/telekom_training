package temporaryFields;

public enum Geschlecht { W, M, D

}
