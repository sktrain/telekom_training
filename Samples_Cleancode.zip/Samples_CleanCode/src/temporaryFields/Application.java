package temporaryFields;

public class Application {
	
	public static void main(String args[]) {
		
		String firstName = args[0];
	    String lastName = args[1];
	    Integer age = Integer.valueOf(args[2]);
	    String occupation = args[3];
	    String city = args[4];
		
		Person p = new Person( firstName, lastName, age, occupation, city);
				
	    p.welcomeNew();
	    p.work();
	    
	}
	
	public static int sum (int a, int b) {
		int result = a+b;
		return result;
	}

}
