package temporaryFields;

public class Person {
	
	private String firstName;
    private String lastName;
    private Integer age;
    private String occupation;
    private String city;
    
	public Person(String firstName, String lastName, Integer age, String occupation, String city) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.occupation = occupation;
		this.city = city;
	}
    
	public void welcomeNew() {
	    System.out.printf("Welcome %s %s, a %d-year-old from %s who works as a%s\n",firstName, lastName, age, city, occupation);
	}
    
	public void work() {
        System.out.printf("This is %s working hard on %s in %s", firstName, occupation, city);
    }
}
