# # Beispiel nach den Bl�cken 2 und 3 der Telekom Akademie

## Schwerpunkte

* Refactoring
  * Code Refactoring
  * Einf�hrung von Interfaces
  * Unterscheidung zwischen api- und impl-Paket 
  

