package org.javacream.books.isbngenerator.api;

public interface IsbnGenerator {

	String next();

}