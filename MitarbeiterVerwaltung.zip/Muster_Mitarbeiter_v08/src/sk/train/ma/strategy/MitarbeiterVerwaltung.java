package sk.train.ma.strategy;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

public class MitarbeiterVerwaltung {
	
	private Mitarbeiter[] marray;
	private List<Mitarbeiter> mlist;
	 
	private TreeSet<Mitarbeiter> mset;
	
	public MitarbeiterVerwaltung() {
		marray = new Mitarbeiter[100];
		
		mlist = new ArrayList<Mitarbeiter>();
		
		
		
		//F�llschleife: 100 Mitarbeiter erzeugen und einf�llen
		// wechselweise  Arbeiter/Fixgehalt
		// zuf�llige Geh�lter
		// Namensgebung anhand F�llschleife
		
		Mitarbeiter m;
		Gehaltsmodell gehalt;
		for (int i = 0; i < marray.length; ++i) {
			if (i%2 == 0) {
				gehalt = new FixGehaltModell(new BigDecimal((int)(Math.random()*10000)));
				m = new Mitarbeiter("Max", "Mustermann" + i,
						  LocalDate.of(1976, 1 + (int)(Math.random()*12), 1), 
						  LocalDate.of(2000,1, 1), Geschlecht.M, 
						  gehalt);
				marray[i] = m;
				mlist.add(m);
			} else {
				gehalt = new ArbeiterModell(new BigDecimal((int)(Math.random()*100)),
						  					new BigDecimal(120));
				m = new Mitarbeiter("Max", "Mustermann" + i,
						  LocalDate.of(1976, 1 + (int)(Math.random()*12), 1), 
						  LocalDate.of(2000,1, 1), Geschlecht.M, 
						  gehalt);
				marray[i] = m;
				mlist.add(m);
			}
			mset = new TreeSet(mlist);
		}
	}
	
	public BigDecimal getGehaltssumme() {
		
		BigDecimal result = BigDecimal.ZERO;
		for (Mitarbeiter m : marray) {
			result = result.add(m.getGehalt().getGehalt());
		}
		return result;
	}

	public Mitarbeiter[] getMarray() {
		return marray;
	}

	public List<Mitarbeiter> getMlist() {
		return mlist;
	}
	
	
	 
	public TreeSet<Mitarbeiter> getMset() {
		return mset;
	}

	@Override
	public String toString() {
		return "MitarbeiterVerwaltung [marray=" + Arrays.toString(marray) + ", mlist=" + mlist + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(marray);
		result = prime * result + ((mlist == null) ? 0 : mlist.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MitarbeiterVerwaltung other = (MitarbeiterVerwaltung) obj;
		if (!Arrays.equals(marray, other.marray))
			return false;
		if (mlist == null) {
			if (other.mlist != null)
				return false;
		} else if (!mlist.equals(other.mlist))
			return false;
		return true;
	}
	

}











