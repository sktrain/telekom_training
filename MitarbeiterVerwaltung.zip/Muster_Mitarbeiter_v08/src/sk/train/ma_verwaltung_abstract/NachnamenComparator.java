package sk.train.ma_verwaltung_abstract;

import java.util.Comparator;

public class NachnamenComparator implements Comparator<Mitarbeiter> {

	@Override
	public int compare(Mitarbeiter o1, Mitarbeiter o2) {
		return o1.getNachname().compareTo(o2.getNachname());
	}

}
