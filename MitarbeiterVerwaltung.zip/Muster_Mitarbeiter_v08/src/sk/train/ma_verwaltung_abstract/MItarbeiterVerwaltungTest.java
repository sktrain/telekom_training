/* Mitarbeiterklasse schreibt als abstrakte Klasse getGehalt-Methode vor.
 * Somit kann in der Mitarbeiterverwaltung die Gehaltssumme berechnet werden.
 * Nebenbei werden eine Anzahl Mitarbeiter als Testdaten generiert und sowohl 
 * als Liste als auch als Array verwaltet.
 * Zus�tzlich Ausgabe im Textformat in Datei.
 */

package sk.train.ma_verwaltung_abstract;

//import java.io.IOException;
//import java.io.Writer;
//import java.nio.charset.StandardCharsets;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.Comparator;

public class MItarbeiterVerwaltungTest {

	public static void main(String[] args) {

		MitarbeiterVerwaltung mv = new MitarbeiterVerwaltung();
		
		mv.writeToFile("ma.txt");
		
//		System.out.println(mv);
//		
//		System.out.println("\n***********************************\n");
//
//		System.out.println("Gehaltsumme: " + mv.getGehaltssumme());
//		
//		Mitarbeiter [] ma = mv.getMarray();
//		
//		for (Mitarbeiter m : ma) {
//			System.out.println(m);
//		}
//		
//		Arrays.sort(ma);
//		
//		
//		System.out.println("\n *********************************************\n");
//		
//		for (Mitarbeiter m : ma) {
//			System.out.println(m);
//			
//		}
//		
//		Comparator<Mitarbeiter> cm = 
//				( o1,  o2) -> o1.getNachname().compareTo(o2.getNachname());
//		
//		Arrays.sort(ma, cm );
//		
//		
////		{
////
////			@Override
////			public int compare(Mitarbeiter o1, Mitarbeiter o2) {
////				return o1.getNachname().compareTo(o2.getNachname());
////			}
////			
////		});
//		
//		
//		System.out.println("\n *********************************************\n");
//		
//		for (Mitarbeiter m : ma) {
//			System.out.println(m);
//		}
//		
//		Comparator<Mitarbeiter> cl = 
//				( o1,  o2) -> o1.getGebdatum().compareTo(o2.getGebdatum());
//		
//		//mal die Exception provozieren
////		mv.getMlist().get(0).setNachname("A");
//
//
//		
////		Writer out = null;
////		
////		try {
////		    out = Files.newBufferedWriter(Paths.get("mitarbeiter.txt"), StandardCharsets.ISO_8859_1);
////			for (Mitarbeiter m : mv.getMarray()) {
////				out.write(m.toString());
////			    out.write(System.lineSeparator());
////			}
////			out.flush();
////		} catch (IOException e) {
////			e.printStackTrace();
////		} finally {
////			try {
////				out.close();
////			} catch (IOException e) {
////				// TODO Auto-generated catch block
////				e.printStackTrace();
////			}
////		}
//		

		 
	}

}
