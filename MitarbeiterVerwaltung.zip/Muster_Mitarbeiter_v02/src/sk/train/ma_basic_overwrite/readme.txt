Basisversion der Mitarbeiterklasse mit �berschriebenen Standardmethoden 
(toString, equals, hashcode) und einem Enum f�rs Geschlecht