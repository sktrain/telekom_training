package sk.train.ma_basic_overwrite;

public enum Geschlecht { W, M, D }
