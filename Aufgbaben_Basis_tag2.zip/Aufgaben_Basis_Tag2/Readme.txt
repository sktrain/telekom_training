Ausgangspunkt ist die Modellierung eines Mitarbeiters als Mitarbeiterklasse mit Datenattribut Gehaltsmodell
(Has-A-Beziehung) und Gehaltsmodelle setzen das Interface Gehaltsmodell um. Kann nat�rlich zuk�nftig flexibel
um weitere Gehaltsmodelle erg�nzt werden.



Aufgaben (Es sollte nat�rlich immer ein Aufrufer (main-Methode oder optional JUnit-Test) geschrieben werden.

1) Erg�nze den vorliegenden Code um vern�nftige Implementierungen der Standard-Methoden der Klasse Object
(toString(), equals() und hashcode()).



2)  Erg�nze den vorliegenden Code um eine Mitarbeiterverwaltungsklasse, die intern ein Array von 100 
Mitarbeitern h�lt. Beim Instantiieren dieser Klasse wird das Array intern zur H�lfte mit Arbeitern 
(Mitarbeiter mit Gehaltsmodell Arbeiter) und Fixgehalt-Mitarbeitern (Mitarbeiter mit Gehaltsmodell Fixgehalt)
bef�llt. D.h. die Klasse bietet einen parameterlosen Konstruktor an, in dem die eigentliche Arbeit passiert.
 
Die Gehaltswerte, Datumsangaben (Einstellungsdatum und/oder Geburtsdatum) sollten variieren 
(Hinweis: java.lang.Math.random() oder java.util.Random-Klasse) ebenso wie die Namen 
(z.B. Laufindex der F�llschleife anf�gen).

Die Klasse sollte zumindest eine Methode anbieten, die die Gehaltssumme aller Mitarbeiter liefert und 
eine Methode, die das gef�llte Mitarbeiter-Array liefert.

Optional kann diese Klasse nat�rlich auch um Implementierungen der Standard-Methoden aus der Klasse Object
erweitert werden.



3) Erg�nze den vorhanden Code um mimimales Exception-Handling: 
Zum Beispiel sollte bei �bergabe eines nichtakzeptablen Nachnamens (leer oder null) f�r Mitarbeiter
eine Exception geworfen werden. Idealerweise in Form einer eigenen Exceptionklasse.



4) Erg�nzung um eine Factory-Klasse, die Gehaltsmodelle mit default-Werten (frei festlegbar) liefert.



5) Umsetzen der nat�rlichen Ordnung in der Mitarbeiterklasse anhand des Gehaltswertes
(Implementierung des Interfaces Comparable) und mal Sortierung des von der Mitarbeiterverwaltung
gelieferten Arrays.



6) Erg�nzung um weitere externe Sortierkriterien (Comparator-Interface), z.B. nach Namen und Datumswerten
und entsprechender Sortierung des von der Mitarbeiterverwaltung gelieferten Arrays.



7) Umstellung der Mitarbeiterverwaltung auf interne Nutzung einer Map<String, Mitarbeiter> statt 
des Arrays. Erg�nzung dieser Klasse mit Methoden um Mitarbeiter zu entfernen bzw. neu aufzunehmen.
Erg�nzung um eine Methode, die das Sortierkriterium als Lambda erwartet und eine entsprechend sortierte
Liste von Mitarbeitern zur�ckgibt.



8) Erg�nzung der Factory-Klasse, um die default-Werte aus einer Properties-Datei zu lesen.



9) Erg�nzung der Mitarbeiterverwaltung um Methoden zum Schreiben der Mitarbeiterliste im Textformat
 in eine Datei, sowie per ObjektSerialisierung zum Speichern und Wiedereinlesen der Liste.
 
 

10) Erg�nzung um eine kleine GUI (Swing), so dass die Mitarbeiter mit Hilfe von JTable in Form
einer Tabelle grafisch dargestellt werden.



11) Umstellung der Mitarbeiterverwaltung auf Datenbankzugriff: Mitarbeiter werden aus der Datenbank
eingelesen.
dargestellt werden
