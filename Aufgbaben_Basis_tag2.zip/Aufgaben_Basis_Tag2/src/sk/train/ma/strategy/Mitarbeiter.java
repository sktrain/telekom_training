/* Bereinigte Klasse mit Gehaltsmodell
 * 
 */

package sk.train.ma.strategy;

//import java.math.BigDecimal;
import java.time.LocalDate;

public class Mitarbeiter  {

	// statische Elemente
	// private static int zaehler = 100000;

	// Datenattribute
	private String persnr;
	private String vorname;
	private String nachname;
	private LocalDate gebdatum;
	private LocalDate einstdatum;
	private Geschlecht geschlecht;
	private Gehaltsmodell gehalt;

	// Konstruktoren
	public Mitarbeiter(int persnr, String vorname, String nachname, LocalDate gebdatum, LocalDate einstdatum,
			           Geschlecht geschlecht, Gehaltsmodell gehalt) {
		super();
		//this.persnr = "PO" + zaehler;
		//++zaehler;
		this.persnr = "PO" + persnr;
		this.vorname = vorname;
		this.nachname = nachname;
		this.gebdatum = gebdatum;
		this.einstdatum = einstdatum;
		this.geschlecht = geschlecht;
		this.gehalt = gehalt;
	}

	// Getter/Setter

	public String getVorname() {
		return vorname;
	}

	public Geschlecht getGeschlecht() {
		return geschlecht;
	}

	public void setGeschlecht(Geschlecht geschlecht) {
		this.geschlecht = geschlecht;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getPersnr() {
		return persnr;
	}

	public LocalDate getGebdatum() {
		return gebdatum;
	}

	public LocalDate getEinstdatum() {
		return einstdatum;
	}

	public Gehaltsmodell getGehalt() {
		return gehalt;
	}

	public void setGehalt(Gehaltsmodell gehalt) {
		this.gehalt = gehalt;
	}

}
