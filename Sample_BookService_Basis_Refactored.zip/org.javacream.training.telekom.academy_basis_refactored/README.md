# Beispiel nach den Bl�cken 2 und 3 der Telekom Akademie

## Schwerpunkte

* Simples Programmieren
  * RandomIsbnGenerator mit Properties, Constructor, java.util.Random
  * Datenstruktur Book, hier insbesondere auch auf die generierten Funktionen (toString etc) 
  * Vererbung: Book, SchoolBook, SpecialistBook
  * Collections: MapStoreService mit einer verschachtelten Hashmap
  * Streaming-API und Lambda-Funktionen: MapBooksService mit den diversen find- und list-Methoden
  * Funktionale Programmierung: Die Generators-Map im MapBooksService

## Hinweise

* Das Beispiel enth�lt kein javadoc. 
* Schnittstellen sind grob behandelt durch Implementierung von Comparable im Book
* Ein enum-Beispiel ist mit Ordering gegeben
* Das Beispiel zur funktionalen Programmierung in Generators-Map ist ein wenig fortgeschritten
* M�gliche Erweiterungen:
  * Nat�rlich beliebige zus�tzliche Subklassen von Book.
  * Weitere Such-Methoden
  * Zus�tzliche Sortier-Methoden und damit Einf�hrung des Comparator-Interfaces
  * Einlesen von Properties-Dateien zum Bef�llen der Store-Kategorien   
