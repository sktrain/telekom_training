package org.javacream.store.api;

public interface StoreService {

	int getStock(String category, String id);

}