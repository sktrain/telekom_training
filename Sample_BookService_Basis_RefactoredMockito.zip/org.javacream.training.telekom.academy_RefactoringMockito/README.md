# Musterl�sung nach Block 4 der Telekom Akademie

## Schwerpunkte

* Refactoring
  * Code Refactoring
  * Einf�hrung von Interfaces
  * Unterscheidung zwischen api- und impl-Paket 
  * Einf�hrung "richtiger" Tests	
  * BooksServiceOperationsTest: Testet alle Methoden
  * BooksServiceScenarioTest: Ausf�hrung einer Test-Sequenz 
  * BooksServiceFindBookByIsbnTest: Beispiel f�r einen Test mit Mock-Objekten und Mockito

## Hinweise

* M�gliche Erweiterungen:
  * Tests f�r IsbnGenerator und StoreService
  * Je nach Zeit und Lust weitere Tests mit Mock-Objekten

